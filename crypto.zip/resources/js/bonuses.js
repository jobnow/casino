import { copyToClipboard } from './utils'

// expose copyToClipboard as a global function
window.copyToClipboard = copyToClipboard;