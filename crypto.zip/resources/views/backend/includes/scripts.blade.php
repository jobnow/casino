<script type="text/javascript" src="{{ asset('js/variables.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/locale.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/manifest.js') }}"></script>
<script type="text/javascript" src="{{ mix('js/vendor.js') }}"></script>
<script type="text/javascript" src="{{ mix('js/app.js') }}"></script>
@stack('scripts')