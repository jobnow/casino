<script type="text/javascript" src="<?php echo e(asset('js/variables.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/locale.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/manifest.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(mix('js/vendor.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>